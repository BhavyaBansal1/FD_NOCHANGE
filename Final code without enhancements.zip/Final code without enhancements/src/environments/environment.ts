export const environment = {
    production: false, 
    apiBaseUrl: 'http://localhost:5251', 
    assetsPath: 'assets/', 
    logoFileName: 'logo1.png', 
    allowedEmailDomains: ['gmail.com','yahoo.com','hotmail.com','example.com', 'test.com'],
  };
  
