// using System.Collections.Generic;

// namespace WisVestAPI.Models
// {
//     public class AssetAllocationResponse
//     {
//         public double Percentage { get; set; }
//         public Dictionary<string, SubAssetAllocationResponse> SubAssets { get; set; }
//     }

//     public class SubAssetAllocationResponse
//     {
//         public double Percentage { get; set; }
//         public List<ProductAllocation> Products { get; set; }
//     }

//     public class ProductAllocation
//     {
//         public string ProductName { get; set; }
//         public double AllocationPercentage { get; set; }
//     }
// }